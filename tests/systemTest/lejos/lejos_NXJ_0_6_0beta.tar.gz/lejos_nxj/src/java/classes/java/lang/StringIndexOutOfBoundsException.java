package java.lang;

public class StringIndexOutOfBoundsException extends RuntimeException 
{
}
