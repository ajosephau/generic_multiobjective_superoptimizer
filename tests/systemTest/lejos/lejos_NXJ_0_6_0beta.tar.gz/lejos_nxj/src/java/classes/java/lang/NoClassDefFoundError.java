package java.lang;

public class NoClassDefFoundError extends Error
{
  public NoClassDefFoundError (String aMessage)
  {
  }
}
