package java.lang;

public class NumberFormatException extends IllegalArgumentException {

}
