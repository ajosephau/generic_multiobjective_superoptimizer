package javax.microedition.lcdui;

/**
 * 
 * @author Andre Nijholt
 */
public interface ItemStateListener {
	public void itemStateChanged(Item item) ;
}
