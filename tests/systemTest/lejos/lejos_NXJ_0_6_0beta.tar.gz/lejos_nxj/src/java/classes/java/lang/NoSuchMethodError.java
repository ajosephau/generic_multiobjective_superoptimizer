package java.lang;

public class NoSuchMethodError extends Error
{
}
